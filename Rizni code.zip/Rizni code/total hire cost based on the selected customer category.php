<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get values from POST request
    $days = $_POST['days'];
    $customer_category = $_POST['customer_category'];

    // Define daily rates based on customer category
    $daily_rates = [
        'regular' => 50,  // Regular customer rate
        'member' => 40,   // Member customer rate
        'vip' => 30       // VIP customer rate
    ];

    // Validate inputs
    if (is_numeric($days) && $days > 0) {
        // Determine daily rate based on category
        $daily_rate = $daily_rates[$customer_category];

        // Calculate total cost
        $total_cost = $days * $daily_rate;

        // Display result
        echo "<h2>Total Hire Cost</h2>";
        echo "<p>For $days day(s) as a $customer_category at \$$daily_rate per day, the total cost is: \$$total_cost.</p>";
    } else {
        echo "<p>Please enter a valid positive number for days.</p>";
    }
}
?>