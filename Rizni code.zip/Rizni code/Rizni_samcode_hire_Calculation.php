<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get values from POST request
    $days = $_POST['days'];
    $daily_rate = $_POST['daily_rate'];

    // Validate inputs
    if (is_numeric($days) && is_numeric($daily_rate) && $days > 0 && $daily_rate > 0) {
        // Calculate total cost
        $total_cost = $days * $daily_rate;

        // Display result
        echo "<h2>Total Hire Cost</h2>";
        echo "<p>For $days day(s) at \$$daily_rate per day, the total cost is: \$$total_cost.</p>";
    } else {
        echo "<p>Please enter valid positive numbers for days and daily rate.</p>";
    }
}
?>